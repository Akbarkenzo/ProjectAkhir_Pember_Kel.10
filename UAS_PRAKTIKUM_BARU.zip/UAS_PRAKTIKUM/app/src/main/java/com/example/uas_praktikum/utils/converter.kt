package com.example.uas_praktikum.utils

import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.room.KategoriTiket

fun List<TravelResponse>.toListKategoriEntity(): List<KategoriTiket> =
    map{
        KategoriTiket(
            id = it.id.toInt(),
            bus = it.typebus,
            hargab = it.harga,
            nam = it.nama,
            des = it.deskripsi,
            fas = it.fasilitas,
            fo = it.foto,
        )
    }

fun List<KategoriTiket>.toListKategoriResponse() : List<TravelResponse> =
    map{
        TravelResponse(
            id = it.id.toString(),
            typebus = it.bus,
            harga = it.hargab,
            nama = it.nam,
            deskripsi = it.des,
            fasilitas = it.fas,
            foto = it.fo,
        )
    }

fun KategoriTiket.toKategoriResponse() : TravelResponse =
    TravelResponse(
        id = id.toString(),
        typebus = bus,
        harga = hargab,
        nama = nam,
        deskripsi = des,
        fasilitas = fas,
        foto = fo,
    )