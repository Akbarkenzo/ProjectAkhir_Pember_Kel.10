package com.example.uas_praktikum.utils

import android.content.Context
import com.example.uas_praktikum.data.AppRepository
import com.example.uas_praktikum.room.AppDatabase



object DependencyInjection {

    fun provideRepository(context: Context) : AppRepository {
        val database = AppDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val appDao = database.appDao()
        val kategoriDao = database.kategoriDao()
        return AppRepository.getInstance(appDao, kategoriDao, appExecutors)
    }

}