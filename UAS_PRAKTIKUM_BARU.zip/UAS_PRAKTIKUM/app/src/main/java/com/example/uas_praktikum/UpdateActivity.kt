package com.example.uas_praktikum

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.app.DatePickerDialog
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.example.uas_praktikum.retrofit.APIConfig
import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.data.AppViewModel
import com.example.uas_praktikum.data.ViewModelFactory
import com.example.uas_praktikum.room.tiketdatabase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar

class UpdateActivity : AppCompatActivity() {

    private lateinit var appViewModel: AppViewModel
    private lateinit var inputNamaEditText: TextInputEditText
    private lateinit var inputTypeBus: MaterialAutoCompleteTextView
    private lateinit var inputHarga: TextInputEditText
    private lateinit var jadwal: EditText
    private var busOptions = emptyList<TravelResponse>()
    private lateinit var getData: tiketdatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        getData = intent.getParcelableExtra("data")!!

        val factory = ViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        inputNamaEditText = findViewById(R.id.upd_name_edit)
        inputTypeBus = findViewById(R.id.upd_bus_edit)
        inputHarga = findViewById(R.id.upd_harga_edit)
        jadwal = findViewById(R.id.upd_jadwal_edit)

        inputNamaEditText.setText(getData.name)
        inputTypeBus.setText(getData.typebus)
        inputHarga.setText(getData.harga)
        jadwal.setText(getData.tanggal)

        val apiService = APIConfig.getApiService()

        apiService.getAllKategori().enqueue(object : Callback<List<TravelResponse>> {
            override fun onResponse(call: Call<List<TravelResponse>>, response: Response<List<TravelResponse>>) {
                if (response.isSuccessful) {
                    val categories = response.body()
                    if (categories != null) {
                        busOptions = categories
                        val busNames = busOptions.map { it.typebus }
                        val adapter = ArrayAdapter(this@UpdateActivity, android.R.layout.simple_dropdown_item_1line, busNames)
                        inputTypeBus.setAdapter(adapter)
                    }
                } else {
                }
            }

            override fun onFailure(call: Call<List<TravelResponse>>, t: Throwable) {
            }
        })

        jadwal.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(this@UpdateActivity, { _, y, m, d ->
                jadwal.setText("$d/${m + 1}/$y")
            }, year, month, day)
            datePickerDialog.show()
        }

        inputTypeBus.setOnItemClickListener { parent, view, position, id ->
            val selectedBus = parent.getItemAtPosition(position) as String
            val selectedBusOption = busOptions.find { it.typebus == selectedBus }
            if (selectedBusOption != null) {
                inputHarga.setText(selectedBusOption.harga)
            }
        }

        val btnSimpan: Button = findViewById(R.id.btn_simpan)
        btnSimpan.setOnClickListener {
            if (validateInput()) {
                updateOrder()
                finish()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (inputNamaEditText.text.toString().isEmpty()) {
            error++
            inputNamaEditText.error = "Masukkan nama terlebih dahulu!"
        }

        if (inputTypeBus.text.toString().isEmpty()) {
            error++
            inputTypeBus.error = "Pilih jenis bus terlebih dahulu!"
        }

        if (inputHarga.text.toString().isEmpty()) {
            error++
            inputHarga.error = "Masukkan harga terlebih dahulu!"
        }

        if (jadwal.text.toString().isEmpty()) {
            error++
            jadwal.error = "Masukkan tanggal keberangkatan terlebih dahulu!"
        }

        return error == 0
    }

    private fun updateOrder() {
        val updatedTiket = tiketdatabase(
            id = getData.id,
            name = inputNamaEditText.text.toString(),
            typebus = inputTypeBus.text.toString(),
            harga = inputHarga.text.toString(),
            tanggal = jadwal.text.toString(),
            desk = "Tiket Bus",
            fasl = "Pending",
            fot = "fotoUri"
        )
        appViewModel.updateTiket(updatedTiket)
    }
}