package com.example.uas_praktikum.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.uas_praktikum.retrofit.APIConfig
import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.room.AppDao
import com.example.uas_praktikum.room.KategoriDao
import com.example.uas_praktikum.room.KategoriTiket
import com.example.uas_praktikum.room.tiketdatabase
import com.example.uas_praktikum.utils.AppExecutors
import com.example.uas_praktikum.utils.toListKategoriEntity
import com.example.uas_praktikum.utils.toListKategoriResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AppRepository private constructor(
    private val appDao: AppDao,
    private val kategoriDao: KategoriDao,
    private val appExecutors: AppExecutors
) {

    private val listtiket = MutableLiveData<List<TravelResponse>>()
    var ListTiket: LiveData<List<TravelResponse>> = listtiket

    fun getAllKategori() {
        val service = APIConfig.getApiService().getAllKategori()
        service.enqueue(object : Callback<List<TravelResponse>> {
            override fun onResponse(
                call: Call<List<TravelResponse>>,
                response: Response<List<TravelResponse>>
            ) {

                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    listtiket.value = response.body()

                    appExecutors.diskIO().execute {
                        kategoriDao.insertAllKategori(responseBody.toListKategoriEntity())
                    }
                } else {
                    Log.e("Error on Response", "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<TravelResponse>>, t: Throwable) {
                Log.e("Error on Failure", "onFailure: ${t.message}")
                appExecutors.diskIO().execute {
                    listtiket.postValue(kategoriDao.getAllKategoriList().toListKategoriResponse())
                }
            }
        })
    }

    fun insertTiket(appEntity: tiketdatabase) {
        appExecutors.diskIO().execute { appDao.insertTiket(appEntity) }
    }

    fun updateTiket(appEntity: tiketdatabase) {
        appExecutors.diskIO().execute { appDao.updateTiket(appEntity) }
    }

    fun deleteTiket(appEntity: tiketdatabase) {
        appExecutors.diskIO().execute { appDao.deleteTiket(appEntity) }
    }

    fun getAllTiket(): LiveData<List<tiketdatabase>> = appDao.getAllTiket()

    fun getAllKategoriBus(): LiveData<List<KategoriTiket>> = kategoriDao.getAllKategori()
    companion object {
        @Volatile
        private var instance: AppRepository? = null

        fun getInstance(
            appDao: AppDao,
            kategoriDao: KategoriDao,
            appExecutors: AppExecutors
        ): AppRepository =
            instance ?: synchronized(this) {
                instance ?: AppRepository(appDao, kategoriDao, appExecutors)
            }.also { instance = it }
    }
}