package com.example.uas_praktikum.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface AppDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertTiket(appEntity: tiketdatabase)

    @Update
    fun updateTiket(appEntity: tiketdatabase)

    @Delete
    fun deleteTiket(appEntity: tiketdatabase)

    @Query("SELECT * FROM tiketdatabase ORDER BY id DESC")
    fun getAllTiket() : LiveData<List<tiketdatabase>>
}