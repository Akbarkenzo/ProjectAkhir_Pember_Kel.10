package com.example.uas_praktikum.retrofit

import retrofit2.Call
import retrofit2.http.GET

interface APIService {

    @GET("travel")
    fun getAllKategori() : Call<List<TravelResponse>>

}
