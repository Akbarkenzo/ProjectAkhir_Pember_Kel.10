package com.example.uas_praktikum

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uas_praktikum.adapter.KategoriAdapter
import com.example.uas_praktikum.data.AppViewModel
import com.example.uas_praktikum.data.ViewModelFactory
import com.example.uas_praktikum.room.KategoriTiket

class homee : AppCompatActivity() {
    private lateinit var appViewModel: AppViewModel
    private lateinit var kategoriAdapter: KategoriAdapter
    private lateinit var kategoriRecyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.home)

        adapter()
        viewmodelupdate()

        val btnorder = findViewById<ImageButton>(R.id.order)
        btnorder.setOnClickListener {
            val intent = Intent(this, intii::class.java)
            startActivity(intent)
        }
    }



    private fun adapter() {
        kategoriRecyclerView = findViewById(R.id.pilihan)
        kategoriRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)


    }

    private fun viewmodelupdate() {

        val viewmodelfactory = ViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, viewmodelfactory) [AppViewModel::class.java]
        appViewModel.getAllKategori()
        appViewModel.getAllKategoribus().observe(this) { kategoriData ->
            if (kategoriData != null) {
                kategoriAdapter = KategoriAdapter(kategoriData)
                kategoriRecyclerView.adapter = kategoriAdapter


                Log.d("homee", "KategoriData: $kategoriData" )

                kategoriAdapter.setOnItemClickCallback(object : KategoriAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: KategoriTiket) {
                        showSelectedCategory(data)
                    }
                })
            }
        }
    }

    private fun showSelectedCategory(data: KategoriTiket) {
        val navigate = Intent(this, deskripsibisActivity::class.java)
        navigate.putExtra("bus", data.bus)
        navigate.putExtra("hargab", data.hargab)
        navigate.putExtra("nam", data.nam)
        navigate.putExtra("des", data.des)
        navigate.putExtra("fas", data.fas)
        navigate.putExtra("fo", data.fo)
        startActivity(navigate)




    }

}