package com.example.uas_praktikum

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.uas_praktikum.room.tiketdatabase

class DetailActivity : AppCompatActivity(){



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val getData = intent.getParcelableExtra<tiketdatabase>("data")!!
        val tiketId = findViewById<TextView>(R.id.NamaPemesan)
        val typeBus = findViewById<TextView>(R.id.TipeBus)
        val harga = findViewById<TextView>(R.id.Harga)
        val tanggal = findViewById<TextView>(R.id.TanggalPemesanan)

        tiketId.text = getData.name.toString()
        typeBus.text = getData.typebus.toString()
        harga.text = getData.harga.toString()
        tanggal.text = getData.tanggal.toString()
    }
}