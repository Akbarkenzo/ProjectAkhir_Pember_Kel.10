package com.example.uas_praktikum

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.app.DatePickerDialog
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.example.uas_praktikum.retrofit.APIConfig
import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.data.AppViewModel
import com.example.uas_praktikum.data.ViewModelFactory
import com.example.uas_praktikum.room.tiketdatabase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Calendar

class OrderActivity : AppCompatActivity() {

    private lateinit var appViewModel: AppViewModel
    private lateinit var nameEdit: TextInputEditText
    private lateinit var busEdit: MaterialAutoCompleteTextView
    private lateinit var hargaEdit: TextInputEditText
    private lateinit var jadwalEdit: EditText
    private var busOptions = emptyList<TravelResponse>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        val factory = ViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        nameEdit = findViewById(R.id.name_edit)
        busEdit = findViewById(R.id.bus_edit)
        hargaEdit = findViewById(R.id.harga_edit)
        jadwalEdit = findViewById(R.id.jadwal_edit)

        val apiService = APIConfig.getApiService()

        apiService.getAllKategori().enqueue(object : Callback<List<TravelResponse>> {
            override fun onResponse(call: Call<List<TravelResponse>>, response: Response<List<TravelResponse>>) {
                if (response.isSuccessful) {
                    val categories = response.body()
                    if (categories != null) {
                        busOptions = categories
                        val busNames = busOptions.map { it.typebus }
                        val adapter = ArrayAdapter(this@OrderActivity, android.R.layout.simple_dropdown_item_1line, busNames)
                        busEdit.setAdapter(adapter)
                    }
                } else {
                }
            }

            override fun onFailure(call: Call<List<TravelResponse>>, t: Throwable) {
            }
        })

        jadwalEdit.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(this@OrderActivity, { _, y, m, d ->
                jadwalEdit.setText("$d/${m + 1}/$y")
            }, year, month, day)
            datePickerDialog.show()
        }

        busEdit.setOnItemClickListener { parent, view, position, id ->
            val selectedBus = parent.getItemAtPosition(position) as String
            val selectedBusOption = busOptions.find { it.typebus == selectedBus }
            if (selectedBusOption != null) {
                hargaEdit.setText(selectedBusOption.harga)
            }
        }

        val btnSimpan: Button = findViewById(R.id.btn_simpan)
        btnSimpan.setOnClickListener {
            if (validateInput()) {
                saveOrder()
                finish()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (nameEdit.text.toString().isEmpty()) {
            error++
            nameEdit.error = "Masukkan nama terlebih dahulu!"
        }

        if (busEdit.text.toString().isEmpty()) {
            error++
            busEdit.error = "Pilih jenis bus terlebih dahulu!"
        }

        if (hargaEdit.text.toString().isEmpty()) {
            error++
            hargaEdit.error = "Masukkan harga terlebih dahulu!"
        }

        if (jadwalEdit.text.toString().isEmpty()) {
            error++
            jadwalEdit.error = "Masukkan tanggal keberangkatan terlebih dahulu!"
        }

        return error == 0
    }

    private fun saveOrder() {
        val order = tiketdatabase(
            id = 0,
            name = nameEdit.text.toString(),
            typebus = busEdit.text.toString(),
            harga = hargaEdit.text.toString(),
            tanggal = jadwalEdit.text.toString(),
            desk = "Tiket Bus",
            fasl = "Pending",
            fot = "fotoUri"


        )
        appViewModel.insertTiket(order)
    }
}
