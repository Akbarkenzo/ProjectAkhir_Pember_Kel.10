package com.example.uas_praktikum

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.uas_praktikum.homee

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val btnnext = findViewById<Button>(R.id.btn_next)
        btnnext.setOnClickListener {
            val intent = Intent(this, homee::class.java)
            startActivity(intent)
        }
    }
}