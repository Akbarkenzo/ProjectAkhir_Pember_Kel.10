package com.example.uas_praktikum


import android.net.Uri
import android.os.Bundle

import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class deskripsibisActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.deskripsi_bis)
        val nama = findViewById<TextView>(R.id.nama)
        val deskripsi = findViewById<TextView>(R.id.deskrip)
        val gambar = findViewById<ImageView>(R.id.image)
        val typebus = findViewById<TextView>(R.id.typebus)
        val harga = findViewById<TextView>(R.id.harga)
        val fasili = findViewById<TextView>(R.id.fasili)

        val getbus = intent.getStringExtra("bus")
        val gethargab = intent.getStringExtra("hargab")
        val getnam = intent.getStringExtra("nam")
        val getdes = intent.getStringExtra("des")
        val getfas = intent.getStringExtra("fas")
        val getfo = intent.getStringExtra("fo")

        nama.text = getnam
        deskripsi.text = getdes
        typebus.text = getbus
        harga.text = gethargab
        fasili.text = getfas

        if (getfo != null) {
            val getdatafouri = Uri.parse(getfo)
            Glide.with(this)
                .load(getdatafouri)
                .placeholder(R.drawable.ic_launcher_background)
                .into(gambar)
        }

    }


}