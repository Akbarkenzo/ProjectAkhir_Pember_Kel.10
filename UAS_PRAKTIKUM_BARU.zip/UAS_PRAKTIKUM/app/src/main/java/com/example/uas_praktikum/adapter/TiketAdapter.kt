package com.example.uas_praktikum.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.uas_praktikum.R
import com.example.uas_praktikum.room.tiketdatabase

class TiketAdapter(private var playerList: List<tiketdatabase>) :
    RecyclerView.Adapter<TiketAdapter.PlayerViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: tiketdatabase)
        fun onDelete(data: tiketdatabase, position: Int)
        fun onUpdate(data: tiketdatabase)
    }

    class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val Nama: TextView = itemView.findViewById(R.id.isinama)
        val Bus: TextView = itemView.findViewById(R.id.kbus)
        val Harga: TextView = itemView.findViewById(R.id.isiharga)
        val Tanggal: TextView = itemView.findViewById(R.id.isitanggal)
        val btnEdit: ImageView = itemView.findViewById(R.id.btn_edit)
        val btnHapus: ImageView = itemView.findViewById(R.id.btn_hapus)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PlayerViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.tiket, parent, false)
        return PlayerViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val data = playerList[position]

        holder.Nama.text = data.name
        holder.Bus.text = data.typebus
        holder.Harga.text = data.harga
        holder.Tanggal.text = data.tanggal

        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(playerList[holder.adapterPosition]) }

        holder.btnHapus.setOnClickListener {
            onItemClickCallback.onDelete(
                playerList[holder.adapterPosition],
                holder.adapterPosition
            )
        }

        holder.btnEdit.setOnClickListener { onItemClickCallback.onUpdate(playerList[holder.adapterPosition]) }

    }

    override fun getItemCount(): Int = playerList.size
}