package com.example.uas_praktikum.retrofit

data class TravelResponse(

    val typebus: String,

    val harga: String,

    val nama: String,

    val deskripsi: String,

    val fasilitas: String,

    val foto: String,

    val id: String
)
