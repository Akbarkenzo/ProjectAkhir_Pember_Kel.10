package com.example.uas_praktikum.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.uas_praktikum.R
import com.example.uas_praktikum.room.KategoriTiket


class KategoriAdapter(private var kategoriList: List<KategoriTiket>) :
    RecyclerView.Adapter<KategoriAdapter.PlayerViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: KategoriTiket)

    }

    class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val Nama: TextView = itemView.findViewById(R.id.namabu)
        val Harga: TextView = itemView.findViewById(R.id.hargabu)
        val foto: ImageView = itemView.findViewById(R.id.foto)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PlayerViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.pilihanbus, parent, false)
        return PlayerViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        val data = kategoriList[position]

        holder.Nama.text = data.nam
        holder.Harga.text = data.hargab
        // Mengatur image
        Glide.with(holder.foto)
            .load(data.fo)
            .into(holder.foto)


        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(kategoriList[holder.adapterPosition]) }





    }

    override fun getItemCount(): Int = kategoriList.size
}
