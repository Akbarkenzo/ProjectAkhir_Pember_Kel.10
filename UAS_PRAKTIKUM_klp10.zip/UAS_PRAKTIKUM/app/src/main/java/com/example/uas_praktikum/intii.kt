package com.example.uas_praktikum

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uas_praktikum.adapter.TiketAdapter
import com.example.uas_praktikum.data.AppViewModel
import com.example.uas_praktikum.data.ViewModelFactory
import com.example.uas_praktikum.room.tiketdatabase
import com.google.android.material.floatingactionbutton.FloatingActionButton

class intii : AppCompatActivity() {

    private lateinit var viewModel: AppViewModel
    private lateinit var adapter: TiketAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.inti)

        val btnAdd = findViewById<FloatingActionButton>(R.id.add)
        btnAdd.setOnClickListener {
            val intent = Intent(this, OrderActivity::class.java)
            startActivity(intent)
        }

        val btnhome = findViewById<ImageButton>(R.id.hom)
        btnhome.setOnClickListener {
            val intent = Intent(this, homee::class.java)
            startActivity(intent)
        }

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        viewModel.getAllTiket().observe(this) { ListTiket ->
            adapter = TiketAdapter(ListTiket)
            recyclerView.adapter = adapter
            adapter.setOnItemClickCallback(object : TiketAdapter.OnItemClickCallback {
                override fun onItemClicked(data: tiketdatabase) {
                    startActivity(Intent(this@intii, DetailActivity::class.java).apply {
                        putExtra("data", data)
                    })
                }

                override fun onDelete(data: tiketdatabase, position: Int) {
                    popUpDelete(data, position)
                }

                override fun onUpdate(data: tiketdatabase) {
                    startActivity(Intent(this@intii, UpdateActivity::class.java).apply {
                        putExtra("data", data)
                    })
                }

            })
        }
    }

    private fun popUpDelete(data: tiketdatabase, position: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Konfirmasi Penghapusan")
        builder.setMessage("Apakah Anda yakin ingin menghapus tiket ini?")

        builder.setPositiveButton("Ya") { dialog, _ ->
            viewModel.deleteTiket(data)
            adapter.notifyItemRemoved(position)
            Toast.makeText(this, "Tiket dihapus", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        builder.setNegativeButton("Tidak") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        viewModel.getAllTiket()
    }
}