package com.example.uas_praktikum.utils

import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.room.KategoriTiket

fun List<TravelResponse>.toListKategoriEntity(): List<KategoriTiket> =
    map{
        KategoriTiket(
            id = it.id.toInt(),
            bus = it.typebus,
            hargab = it.harga,
        )
    }

fun List<KategoriTiket>.toListKategoriResponse() : List<TravelResponse> =
    map{
        TravelResponse(
            id = it.id.toString(),
            typebus = it.bus,
            harga = it.hargab,
        )
    }

fun KategoriTiket.toKategoriResponse() : TravelResponse =
    TravelResponse(
        id = id.toString(),
        typebus = bus,
        harga = hargab,
    )