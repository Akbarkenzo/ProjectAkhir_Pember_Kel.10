package com.example.uas_praktikum

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class homee : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.home)

        val btnorder = findViewById<ImageButton>(R.id.order)
        btnorder.setOnClickListener {
            val intent = Intent(this, intii::class.java)
            startActivity(intent)
        }
        val btneko = findViewById<ImageButton>(R.id.eko)
        btneko.setOnClickListener {
            val intent = Intent(this, ekodes::class.java)
            startActivity(intent)
        }
        val btneks = findViewById<ImageButton>(R.id.eks)
        btneks.setOnClickListener {
            val intent = Intent(this, eksdes::class.java)
            startActivity(intent)
        }
        val btnbis = findViewById<ImageButton>(R.id.bis)
        btnbis.setOnClickListener {
            val intent = Intent(this, bisdes::class.java)
            startActivity(intent)
        }
        val btnvip = findViewById<ImageButton>(R.id.vip)
        btnvip.setOnClickListener {
            val intent = Intent(this, vipdes::class.java)
            startActivity(intent)
        }
        val btnvvip = findViewById<ImageButton>(R.id.vvip)
        btnvvip.setOnClickListener {
            val intent = Intent(this, vvipdes::class.java)
            startActivity(intent)
        }
    }
}