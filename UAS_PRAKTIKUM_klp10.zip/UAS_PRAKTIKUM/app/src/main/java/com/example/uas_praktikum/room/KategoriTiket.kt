package com.example.uas_praktikum.room

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity("kategori")
data class KategoriTiket(
    @PrimaryKey
    val id: Int,

    val bus: String,

    val hargab: String,

) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readString()!!,
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(bus)
        parcel.writeString(hargab)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<KategoriTiket> {
        override fun createFromParcel(parcel: Parcel): KategoriTiket {
            return KategoriTiket(parcel)
        }

        override fun newArray(size: Int): Array<KategoriTiket?> {
            return arrayOfNulls(size)
        }
    }
}