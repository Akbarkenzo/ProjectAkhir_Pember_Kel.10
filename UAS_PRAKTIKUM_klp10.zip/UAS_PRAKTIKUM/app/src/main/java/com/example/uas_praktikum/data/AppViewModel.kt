package com.example.uas_praktikum.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.uas_praktikum.retrofit.TravelResponse
import com.example.uas_praktikum.room.tiketdatabase

class AppViewModel(private val appRepository: AppRepository) : ViewModel() {

    val ListTiket: LiveData<List<TravelResponse>> = appRepository.ListTiket

        fun getAllKategori() {
        appRepository.getAllKategori()
    }

    fun insertTiket(TiketDatabase: tiketdatabase) {
        appRepository.insertTiket(TiketDatabase)
    }

    fun getAllTiket(): LiveData<List<tiketdatabase>> {
        return appRepository.getAllTiket()
    }

    fun updateTiket(appEntity: tiketdatabase) {
        appRepository.updateTiket(appEntity)
    }

    fun deleteTiket(appEntity: tiketdatabase) {
        appRepository.deleteTiket(appEntity)
    }

}