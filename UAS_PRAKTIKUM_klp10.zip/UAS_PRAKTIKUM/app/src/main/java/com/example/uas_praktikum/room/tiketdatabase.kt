package com.example.uas_praktikum.room

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class tiketdatabase(
    @PrimaryKey(autoGenerate = true)
    val id: Int,

    val name: String,

    val typebus: String,

    val harga: String,

    val tanggal: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(name)
        parcel.writeString(typebus)
        parcel.writeString(harga)
        parcel.writeString(tanggal)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<tiketdatabase> {
        override fun createFromParcel(parcel: Parcel): tiketdatabase {
            return tiketdatabase(parcel)
        }

        override fun newArray(size: Int): Array<tiketdatabase?> {
            return arrayOfNulls(size)
        }
    }
}